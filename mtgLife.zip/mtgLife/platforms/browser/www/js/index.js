var count1 = document.getElementById("count1");
var count2 = document.getElementById("count2");


function addp1(ant) {
    var health = Number(count1.innerHTML);
    
    health+=ant;
    count1.innerHTML = health;
    
    if(health < 1){
        count1.style.color = "red";
    } else {
        count1.style.color = "white";
    }
}

function addp2(ant) {
    var health = Number(count2.innerHTML);

    health+=ant;
    count2.innerHTML = health;
    
    if(health < 1){
        count2.style.color = "red";
    } else {
        count2.style.color = "white";
    }
}

function updatePoision1() {
    document.getElementById("poision-counter1").innerHTML = document.getElementById("poision-bar1").value;
    if (document.getElementById("poision-bar1").value === "0") {
        document.getElementById("poision-counter1").innerHTML = "";
    }
}

function updatePoision2() {
    document.getElementById("poision-counter2").innerHTML = document.getElementById("poision-bar2").value;
    if (document.getElementById("poision-bar2").value === "0") {
        document.getElementById("poision-counter2").innerHTML = "";
    }
}

function reset() {
    count1.innerHTML = 20;
    count2.innerHTML = 20;
    count1.style.color = "white";
    count2.style.color = "white";
}

function rollDice() {
    var health1 = count1.innerHTML;
    var health2 = count2.innerHTML;
    
    
    
    document.getElementById("number1").innerHTML = '<img src="img/png/die' + (Math.floor(Math.random() * 6)+1) + '.png" height="80px" width="80px" id="die1">';
    document.getElementById("number2").innerHTML = '<img src="img/png/die' + (Math.floor(Math.random() * 6)+1) + '.png" height="80px" width="80px" id="die2">';
    
    
    setTimeout(function () {
        document.getElementById("number1").innerHTML = '<h1 id="count1">' + health1 + '</h1>';
        document.getElementById("number2").innerHTML = '<h1 id="count2">' + health2 + '</h1>';
        
        count1 = document.getElementById("count1");
        count2 = document.getElementById("count2");
    }, 3000)
    
    
}